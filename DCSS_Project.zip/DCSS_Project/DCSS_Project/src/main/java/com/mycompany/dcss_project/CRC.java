/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dcss_project;

import javax.swing.*;

public class CRC {

    CRC(){

        String data = JOptionPane.showInputDialog("Enter Data");

        String divisor = JOptionPane.showInputDialog("Enter Generator Polynomial");

        JOptionPane.showMessageDialog(null,"CRC Simulation Completed");
    }
}