/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dcss_project;

import javax.swing.*;

public class BitStuffing {

    BitStuffing() {

        String data = JOptionPane.showInputDialog("Enter Binary Data");

        String result="";
        int count=0;

        for(int i=0;i<data.length();i++){

            if(data.charAt(i)=='1'){
                count++;
                result+="1";

                if(count==5){
                    result+="0";
                    count=0;
                }
            }

            else{
                result+="0";
                count=0;
            }
        }

        JOptionPane.showMessageDialog(null,"Stuffed Data: "+result);
    }
}