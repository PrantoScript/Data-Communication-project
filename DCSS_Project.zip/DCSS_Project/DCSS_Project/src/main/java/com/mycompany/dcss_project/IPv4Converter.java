/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dcss_project;

import javax.swing.*;

public class IPv4Converter {

    IPv4Converter(){

        String ip = JOptionPane.showInputDialog("Enter IPv4 Address");

        String parts[] = ip.split("\\.");

        String binary="";

        for(int i=0;i<parts.length;i++){

            int num=Integer.parseInt(parts[i]);
            String bin=Integer.toBinaryString(num);

            while(bin.length()<8)
                bin="0"+bin;

            binary+=bin+".";

        }

        JOptionPane.showMessageDialog(null,"Binary IP: "+binary);
    }
}