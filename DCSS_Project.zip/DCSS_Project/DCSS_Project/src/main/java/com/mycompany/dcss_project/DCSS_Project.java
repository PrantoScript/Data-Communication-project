package com.mycompany.dcss_project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DCSS_Project extends JFrame implements ActionListener {

    JButton bitStuff, ipv4, parity, crc, hamming;

    DCSS_Project() {

        setTitle("Data Communication System Simulator");
        setSize(500,400);
        setLayout(new GridLayout(6,1));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel title = new JLabel("DCSS Simulator", JLabel.CENTER);
        add(title);

        bitStuff = new JButton("Bit Stuffing");
        ipv4 = new JButton("IPv4 Converter");
        parity = new JButton("Parity Checker");
        crc = new JButton("CRC Generator");
        hamming = new JButton("Hamming Code");

        add(bitStuff);
        add(ipv4);
        add(parity);
        add(crc);
        add(hamming);

        bitStuff.addActionListener(this);
        ipv4.addActionListener(this);
        parity.addActionListener(this);
        crc.addActionListener(this);
        hamming.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==bitStuff)
            new BitStuffing();

        if(e.getSource()==ipv4)
            new IPv4Converter();

        if(e.getSource()==parity)
            new ParityChecker();

        if(e.getSource()==crc)
            new CRC();

        if(e.getSource()==hamming)
            new HammingCode();
    }

    public static void main(String[] args) {
        new DCSS_Project();
    }
}