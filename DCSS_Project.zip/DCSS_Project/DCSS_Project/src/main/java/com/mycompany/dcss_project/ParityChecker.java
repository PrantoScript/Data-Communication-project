/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dcss_project;

import javax.swing.*;

public class ParityChecker {

    ParityChecker(){

        String data = JOptionPane.showInputDialog("Enter Binary Data");

        int count=0;

        for(int i=0;i<data.length();i++){

            if(data.charAt(i)=='1')
                count++;

        }

        if(count%2==0)
            JOptionPane.showMessageDialog(null,"Even Parity");

        else
            JOptionPane.showMessageDialog(null,"Odd Parity");
    }
}
